(function (name) {
  function hello(world) {
    return 'Hello ' + world + '!';
  }
  console.log(hello(name));
}('Forbes Lindesay'));
